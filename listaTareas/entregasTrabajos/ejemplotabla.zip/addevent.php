<?php
require("class/todo.class.php"); 
$objtodo=new todo;

if(isset($_POST['submit'])){
	$fecha_texto = $_POST['date']; // fecha en formato texto
	if (preg_match("/[0-9]{1,2}-[0-9]{1,2}-([0-9][0-9]){1,2}/",$fecha_texto))
		list($month,$day,$year)=split("-",$fecha_texto); // extraer valores para convertir a fecha Unix
		
	$fechaUnix = mktime(0,0,0, $month,$day,$year);
	
	$fecha = date('Y-m-d',$fechaUnix);
	$dia = date('d',$fechaUnix);
	$nrodiasemana = date('w',$fechaUnix);
	$mes = date('m',$fechaUnix);
	$descripcion = $_POST['descripcion'];
	$completado = 0;
	
	if($objtodo->add_event(array($fecha,$dia,$nrodiasemana,$mes,$descripcion,$completado))==true)
		echo 'good';
	else
		echo 'error';
}
?>