<?php
class todo{

	var $dayname = array('Domingo','Lunes','Martes','Miercoles','Jueves','Viernes','Sabado');
	
	var $monthname = array(1=>'Enero',2=>'Febrero',3=>'Marzo',4=>'Abril',5=>'Mayo',6=>'Junio',7=>'Julio',8=>'Agosto',9=>'Septiembre',10=>'Octubre',11=>'Noviembre',12=>'Diciembre');
	
 	function todo(){
		//constructor
 	}
	
	function add_dates($date,$ndays){
		if (preg_match("/[0-9]{1,2}\/[0-9]{1,2}\/([0-9][0-9]){1,2}/",$date))
	  		list($day,$month,$year)=split("/", $date);
            

      	if (preg_match("/[0-9]{1,2}-[0-9]{1,2}-([0-9][0-9]){1,2}/",$date))
			list($day,$month,$year)=split("-",$date);
			
       	 	$new = mktime(0,0,0, $month,$day,$year) + $ndays * 24 * 60 * 60;
        	//$newdate=date("d-m-Y",$new);
			$newdate=date($new);
            
     	return ($newdate);  
    }
	
	private function conexion() {
		if(!($con=@mysql_connect("localhost","root",""))){
		 	echo"Error al conectar a la base de datos";	
		 	exit();
	   	}
	   	if (!@mysql_select_db("todo",$con)) {
		 	echo "Error al seleccionar la base de datos";  
		 	exit();
	   	}
	   	return true;	
	 }
	
	function add_event($field){
		 if($this->conexion()==true){
		 	return mysql_query("INSERT INTO activity (fecha, dia, nrodiasemana, mes, descripcion, completado) VALUES ('".$field[0]."', ".$field[1].",".$field[2].",".$field[3].",'".$field[4]."',".$field[5].")");
		 }
	}
	
	function show_event($fecha){
		if($this->conexion()==true){
			return mysql_query("SELECT * FROM activity WHERE fecha='".$fecha."'");
		}
	}
}
 ?>