<?php 
require("class/todo.class.php"); 
$objtodo=new todo;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Lista de tareas</title>
<link type="text/css" rel="stylesheet" href="main.css" />
<script  type="text/javascript" src="js/JQuery.js"></script>
<script  type="text/javascript" src="js/functions.js"></script>

</head>

<body>
<div id="main-days">
	<?php
	$today = date("d-m-Y"); //fecha de hoy
	$i=1;
	while($i<=7){ 
    	$date = $objtodo->add_dates($today, $i-1); //fecha de hoy + 1
		$numdayweek = date("w",$date); //numero de dia de la semana
		$numday = date("d",$date); // día del mes
		$nummonth = date("n",$date); // numero del mes
		$year = date("Y",$date); //año
	?>
	<div class="cols" id="col<?php echo $i?>">
    <span class="dayname" <?php if($i==1) echo 'style="color:#006600;"'?> > <?php echo $objtodo->dayname[$numdayweek] ?></span>
    <span class="datelong"><?php echo $numday." de ".$objtodo->monthname[$nummonth].", ".$year; ?></span>
    <div class="list">
    	<span class="newactivity">
        <input type="text" id="newactivity[<?php echo $i?>]" name="newactivity[<?php echo $i?>]" />
        <input type="hidden" id="date[<?php echo $i?>]" name="date[<?php echo $i?>]" value="<?php echo date("m-d-Y",$date) ?>" />
        </span>
        <div id="activities<?php echo $i?>">
        <?php
		$consulta = $objtodo->show_event(date("Y-m-d",$date));
		
		while( $tareas = mysql_fetch_array($consulta) ){
		?>
        <span class="activity">
			<?php echo $tareas['descripcion'] ?>
        </span>
        <?php
		}
		?>
        </div>
    </div>
  	</div>
    
    <?php 
	$i++;
	}
	?>
</div>
</body>
</html>
