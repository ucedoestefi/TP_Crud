$(document).ready(function(){
						   
	$("input[name^=newactivity]").keypress(function (e) {
		if(e.keyCode == 13){
			var descripcion = $(this).attr('value');
			// capturar indice de input newactivity
			var element_id = $("input[name^=newactivity]").index(this);
			//capturar fecha de campo oculto
			var date = $("#date\\["+(element_id+1)+"\\]").attr('value');
			
			$.ajax({
				url: 'addevent.php',
				type: "POST",
				data: "submit=&date="+date+"&descripcion="+descripcion,
				success: function(datos){
					ShowEventDay(date,element_id+1);
					$("input[name^=newactivity]").attr("value","");
				}
			});
			$(this).focus();
		}
	});
	
});

function ShowEventDay(date,div_id){	
	$.ajax({
		url: 'showeventday.php',
		type: "POST",
		data: "date="+date,
		success: function(datos){
			$("#activities"+div_id).html(datos);
		}
	});
}