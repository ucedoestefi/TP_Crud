<?php
$fecha_texto = $_POST['date'];

if (preg_match("/[0-9]{1,2}-[0-9]{1,2}-([0-9][0-9]){1,2}/",$fecha_texto))
		list($month,$day,$year)=split("-",$fecha_texto); // extraer valores para convertir a fecha Unix
		
$fechaUnix = mktime(0,0,0, $month,$day,$year);
$fecha = date('Y-m-d',$fechaUnix);

require("class/todo.class.php"); 
$objtodo=new todo;

$consulta = $objtodo->show_event($fecha);
while( $tarea = mysql_fetch_array($consulta) ){
	?>
	<span class="activity">
	<?php echo $tarea['descripcion'] ?>
    </span>
<?php
}
?>